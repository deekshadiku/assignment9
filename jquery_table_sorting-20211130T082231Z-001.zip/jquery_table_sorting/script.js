$(document).ready(function () {
  let dataList;
  let countFirstFilter = 0;
  let countSecondFilter = 0;

  $.ajax({
    type: "Get",
    url: "data.json",
    dataType: "json",
    contentType: "application/json",
    data: {},
    success: function (data) {
      dataList = data;
      for (i = 0; i < dataList.length; i++) {
        $("#myTable").append(
          "<tr><td>" +
            dataList[i].id +
            '</td><td class="name">' +
            dataList[i].character +
            "</td><td>" +
            dataList[i].actor +
            "</td><td>" +
            dataList[i].movie +
            "</td><td>" +
            dataList[i].date +
            "</td></tr>"
        );
      }
    },
    error: function () {
      alert("json not found");
    },
  });

  $("#search").keyup(function () {
    var data = this.value.toLowerCase().split(" ");
    $("#myTable tr").each(function (index) {
      var customerId = $(this).find(".name").html();
      if (customerId.toLowerCase().indexOf(data[0]) != -1 && data[0] !== "") {
        $(this).addClass("highlighted");
      } else {
        $(this).removeClass("highlighted");
      }
    });
  });

  $(".firstFilter").on("click", function () {
    $("#myTable tr").each(function (index) {
      $(this).removeClass("hide");
    });
    $("#myTable tr").each(function (index) {
      var customerId = $(this).find(".name").html();
      console.log("td value", customerId.charCodeAt(0));
      if (customerId.charCodeAt(0) <= 77) {
        countFirstFilter++;
      } else {
        $(this).addClass("hide");
      }
      $(".firstFilter").html(`A-M (${countFirstFilter})`);
      $(".firstFilter").attr("disabled", true);
      countSecondFilter = 0;
      $(".secondFilter").attr("disabled", false);
    });
  });

  $(".secondFilter").on("click", function () {
    $("#myTable tr").each(function (index) {
      $(this).removeClass("hide");
    });
    $("#myTable tr").each(function (index) {
      var customerId = $(this).find(".name").html();
      console.log("td value", customerId);
      if (customerId.charCodeAt(0) >= 78) {
        countSecondFilter++;
        // $(this).addClass('visible');
      } else {
        $(this).addClass("hide");
      }
      $(".secondFilter").html(`N-Z (${countSecondFilter})`);
      $(".secondFilter").attr("disabled", true);
      countFirstFilter = 0;
      $(".firstFilter").attr("disabled", false);
    });
  });

  // sorting
  $("th").each(function (column) {
    $(this).click(function () {
      let type = $(this).attr("class");
      let records = $("table").find("#myTable> tr");
      let order = parseInt($(this).data("order"));

      if (order === 0) {
        $(this).find("span").html("&#x25B2;");
        records.sort(function (a, b) {
          let value1 = $(a).children("td").eq(column).text();
          let value2 = $(b).children("td").eq(column).text();
          if (type === "number") {
            value1 *= 1;
            value2 *= 1;
          }
          return value1 > value2 ? 1 : value1 < value2 ? -1 : 0;
        });
        $.each(records, function (i, row) {
          $("#myTable").append(row);
        });
      }

      if (order === 1) {
        $(this).find("span").html("&#x25BC;");
        records.sort(function (a, b) {
          let value1 = $(a).children("td").eq(column).text();
          let value2 = $(b).children("td").eq(column).text();
          if (type === "number") {
            value1 *= 1;
            value2 *= 1;
          }
          return value1 > value2 ? -1 : value1 < value2 ? 1 : 0;
        });
        $.each(records, function (i, row) {
          $("#myTable").append(row);
        });
      }

      if (order === 2) {
        $(this).find("span").html("");
        $("#myTable").empty();

        for (i = 0; i < dataList.length; i++) {
          $("#myTable").append(`
          <tr>
            <td>${dataList[i].id}</td>
            <td class="name">${dataList[i].character}</td>
            <td>${dataList[i].actor}</td>
            <td>${dataList[i].movie}</td>
            <td>${dataList[i].date}</td>
          </tr> `);
        }
      }

      if (order == 0) $(this).data("order", "1");
      else if (order == 1) $(this).data("order", "2");
      else if (order == 2) $(this).data("order", "0");
    });
  });
});
